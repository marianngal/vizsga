import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  /**
   * Alap URL a XAMPP / htdocs / iskola mappához.
   * Itt vannak a PHP végpontok:
   * - osztalyok_read.php
   * - tanulok_read.php
   * - tanulok_create.php
   * - tanulok_update.php
   * - tanulok_delete.php
   */
  private readonly baseUrl = 'http://localhost/iskola';

  constructor(private http: HttpClient) {}

  // -----------------------
  // OSZTÁLYOK (READ)
  // -----------------------
  getOsztalyok(): Observable<any> {
    return this.http.get<any>(`${this.baseUrl}/osztalyok_read.php`);
  }

  // -----------------------
  // DIÁKOK (CRUD)
  // -----------------------
  getDiakok(): Observable<any> {
    return this.http.get<any>(`${this.baseUrl}/tanulok_read.php`);
  }

  createDiak(payload: any): Observable<any> {
    return this.http.post<any>(`${this.baseUrl}/tanulok_create.php`, payload);
  }

  updateDiak(payload: any): Observable<any> {
    return this.http.put<any>(`${this.baseUrl}/tanulok_update.php`, payload);
  }

  deleteDiak(id: number): Observable<any> {
    return this.http.delete<any>(`${this.baseUrl}/tanulok_delete.php?id=${id}`);
  }

  // -----------------------
  // DIÁK (READ ONE)
  // -----------------------
  getDiakById(id: number) {
    return this.http.get<any>(`${this.baseUrl}/tanulok_read_one.php?id=${id}`);
}

}
