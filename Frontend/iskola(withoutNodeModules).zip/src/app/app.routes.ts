import { Routes } from '@angular/router';
import { DiakokListaComponent } from './components/diakok-lista.component/diakok-lista.component';
import { DiakLetrehozasComponent } from './components/diak-letrehozas.component/diak-letrehozas.component';
import { DiakSzerkesztesComponent } from './components/diak-szerkesztes.component/diak-szerkesztes.component';

export const routes: Routes = [
    // Lista (főoldal)
  { path: '', component: DiakokListaComponent },

  // Új diák létrehozása
  { path: 'diak-letrehozas', component: DiakLetrehozasComponent },

  // Diák szerkesztése ID alapján
  { path: 'diak-szerkesztes/:id', component: DiakSzerkesztesComponent },

  // Hiba komponens meghívása, amennyiben rossz útvonalat adnánk meg!
  { path: '**', component: DiakSzerkesztesComponent }
];
