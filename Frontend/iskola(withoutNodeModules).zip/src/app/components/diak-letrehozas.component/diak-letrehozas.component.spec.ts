import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DiakLetrehozasComponent } from './diak-letrehozas.component';

describe('DiakLetrehozasComponent', () => {
  let component: DiakLetrehozasComponent;
  let fixture: ComponentFixture<DiakLetrehozasComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DiakLetrehozasComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DiakLetrehozasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
