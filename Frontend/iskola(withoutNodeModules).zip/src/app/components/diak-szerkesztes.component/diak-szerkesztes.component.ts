import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

import { ApiService } from '../../services/api';
import { Osztaly } from '../../models/osztaly';

@Component({
  selector: 'app-diak-szerkesztes',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './diak-szerkesztes.component.html',
  styleUrls: ['./diak-szerkesztes.component.css']
})
export class DiakSzerkesztesComponent implements OnInit {

  diakId = 0;

  osztalyok: Osztaly[] = [];

  // Ugyanaz az űrlapmodell, mint létrehozásnál
  form = {
    vezeteknev: '',
    keresztnev: '',
    email: '',
    osztaly_id: 0,
    szuletesi_datum: ''
  };

  constructor(
    private api: ApiService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    // ID kiolvasása az URL-ből
    this.diakId = Number(this.route.snapshot.paramMap.get('id'));

    if (!this.diakId) {
      alert('Hiányzó diák azonosító.');
      this.router.navigate(['/']);
      return;
    }

    this.loadOsztalyok();
    this.loadDiak();
  }

  loadOsztalyok(): void {
    this.api.getOsztalyok().subscribe({
      next: (res) => {
        this.osztalyok = res.data;
      },
      error: () => {
        alert('Nem sikerült betölteni az osztályokat.');
      }
    });
  }

  loadDiak(): void {
    this.api.getDiakById(this.diakId).subscribe({
      next: (res) => {
        const d = res.data;

        // űrlap előtöltése
        this.form = {
          vezeteknev: d.vezeteknev,
          keresztnev: d.keresztnev,
          email: d.email,
          osztaly_id: d.osztaly_id,
          szuletesi_datum: d.szuletesi_datum ?? ''
        };
      },
      error: () => {
        alert('A diák adatai nem tölthetők be.');
        this.router.navigate(['/']);
      }
    });
  }

  updateDiak(): void {
    if (!this.form.vezeteknev || !this.form.keresztnev || !this.form.email || this.form.osztaly_id <= 0) {
      alert('Töltsd ki a kötelező mezőket!');
      return;
    }

    const payload = {
      id: this.diakId,
      vezeteknev: this.form.vezeteknev.trim(),
      keresztnev: this.form.keresztnev.trim(),
      email: this.form.email.trim(),
      osztaly_id: Number(this.form.osztaly_id),
      szuletesi_datum: this.form.szuletesi_datum === '' ? null : this.form.szuletesi_datum
    };

    this.api.updateDiak(payload).subscribe({
      next: () => {
        alert('Sikeres módosítás.');
        this.router.navigate(['/']);
      },
      error: () => {
        alert('Hiba történt a módosítás során.');
      }
    });
  }
}
