import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DiakSzerkesztesComponent } from './diak-szerkesztes.component';

describe('DiakSzerkesztesComponent', () => {
  let component: DiakSzerkesztesComponent;
  let fixture: ComponentFixture<DiakSzerkesztesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DiakSzerkesztesComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DiakSzerkesztesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
