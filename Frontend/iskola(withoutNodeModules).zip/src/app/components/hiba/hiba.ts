import { Component } from '@angular/core';

@Component({
  selector: 'app-hiba',
  imports: [],
  templateUrl: './hiba.html',
  styleUrl: './hiba.css',
})
export class Hiba {

}
