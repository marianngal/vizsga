import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../services/api';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-diakok-lista',
  standalone: true,
  imports:[CommonModule,RouterLink],
  templateUrl: './diakok-lista.component.html',
  styleUrls: ['./diakok-lista.component.css']
})
export class DiakokListaComponent implements OnInit {

  diakok: any[] = [];
  loading = false;
  error = '';

  constructor(private api: ApiService) {}

  ngOnInit(): void {
    this.loadDiakok();
  }

  loadDiakok(): void {
    this.loading = true;
    this.error = '';

    this.api.getDiakok().subscribe({
      next: (res) => {
        this.diakok = res.data;
        this.loading = false;
      },
      error: () => {
        this.error = 'Hiba történt a diákok betöltésekor.';
        this.loading = false;
      }
    });
  }

  //Tanuló törlése, így ehhez a funkcióhoz nem kell külön komponens
  deleteDiak(id: number): void {
  if (!confirm('Biztosan törlöd a kiválasztott diákot?')) return;

  this.api.deleteDiak(id).subscribe({
    next: () => {
      // újratöltjük a listát, hogy azonnal eltűnjön a sor
      this.loadDiakok();
    },
    error: () => {
      alert('Hiba történt a törlés során.');
    }
  });
}
}
