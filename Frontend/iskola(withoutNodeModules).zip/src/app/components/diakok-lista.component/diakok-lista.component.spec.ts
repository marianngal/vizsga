import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DiakokListaComponent } from './diakok-lista.component';

describe('DiakokListaComponent', () => {
  let component: DiakokListaComponent;
  let fixture: ComponentFixture<DiakokListaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DiakokListaComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DiakokListaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
