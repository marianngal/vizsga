export interface Osztaly {
  id: number;
  nev: string;
}