export interface Diak {
  id: number;
  vezeteknev: string;
  keresztnev: string;
  email: string;
  osztaly_id: number;
  osztaly_nev: string;
  szuletesi_datum: string | null;
}
