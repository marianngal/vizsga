import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Tanulo } from '../models/tanulo';


@Injectable({
  providedIn: 'root',
})
export class TanuloService {
  private listUrl = 'http://localhost/minta_api/tanulok.php';
  private createUrl = 'http://localhost/minta_api/tanulok_create.php';
  constructor(private http: HttpClient) { }
  getTanulok() { return this.http.get<Tanulo[]>(this.listUrl); }
  createTanulo(body: { nev: string; osztaly: string; pontszam: number }) {
    return this.http.post<{ success: boolean; id?: number; message?: string }>(this.createUrl, body);
  }
}
