import { Component, OnInit } from '@angular/core';
import { Tanulo } from '../../models/tanulo';
import { TanuloService } from '../../services/tanulo.service';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-tanulo-lista.component',
  imports: [CommonModule, RouterLink],
  templateUrl: './tanulo-lista.component.html',
  styleUrl: './tanulo-lista.component.css',
})
export class TanuloListaComponent implements OnInit {
  tanulok: Tanulo[] = []; loading = false; error = ''; info = '';
  constructor(private s: TanuloService) { }
  ngOnInit() { this.load(); }
  load() {
    this.loading = true; this.s.getTanulok().subscribe({
      next: d => { this.tanulok = d; this.loading = false; },
      error: _ => { this.error = 'Hiba a lekéréskor.'; this.loading = false; }
    });
  }
}
