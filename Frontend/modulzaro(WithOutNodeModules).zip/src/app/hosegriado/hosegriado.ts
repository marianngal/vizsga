import { Component } from '@angular/core';

@Component({
  selector: 'app-hosegriado',
  standalone: false,
  templateUrl: './hosegriado.html',
  styleUrl: './hosegriado.css',
})
export class Hosegriado {
  elsoVizsgaltNap!: number;
  masodikVizsgaltNap!: number;
  harmadikVizsgaltNap!: number;

  aktualisRiadoszint(): string {
    if (this.elsoVizsgaltNap != null && this.masodikVizsgaltNap != null && this.harmadikVizsgaltNap != null) {
      if (this.elsoVizsgaltNap >= 27 && this.masodikVizsgaltNap >= 27 && this.harmadikVizsgaltNap >= 27) {
        return "3.szintű";
      }
      else if (this.elsoVizsgaltNap >= 25 && this.masodikVizsgaltNap >= 25 && this.harmadikVizsgaltNap >= 25) {
        return "2.szintű";
      }
      else if (this.elsoVizsgaltNap >= 25 || this.masodikVizsgaltNap >= 25 || this.harmadikVizsgaltNap >= 25) {
        return "1.szintű";
      }
      else {
        return "0.szintű"
      }
    }
    else {
      return "hiányzó adat!"
    }
  }

  eredmenyek: string[] = [];
  eredmenyMentes(): void {
    if (this.elsoVizsgaltNap != null && this.masodikVizsgaltNap != null && this.harmadikVizsgaltNap != null) {
      this.eredmenyek.push(`${this.elsoVizsgaltNap},${this.masodikVizsgaltNap},${this.harmadikVizsgaltNap} esetén ${this.aktualisRiadoszint()} hőségriadó volt elrendelve`);
    }
  }

}
