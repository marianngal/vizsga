import { Component } from '@angular/core';

@Component({
  selector: 'app-hiba404',
  standalone: false,
  templateUrl: './hiba404.html',
  styleUrl: './hiba404.css',
})
export class Hiba404 {

}
