import { Component } from '@angular/core';

@Component({
  selector: 'app-hiba',
  standalone: false,
  templateUrl: './hiba.html',
  styleUrl: './hiba.css',
})
export class Hiba {

}
