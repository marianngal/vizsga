﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ViewModellKozott.ViewModel;

namespace ViewModellKozott.View
{
    /// <summary>
    /// Interaction logic for Kreta.xaml
    /// </summary>
    public partial class Kreta : Window
    {
        // Vegyünk fel egy napló példányt!
        private Naplo naplo = new();

        public Kreta()
        {
            InitializeComponent();

            // Az ablaknak ezt kell megjelenítenie
            DataContext = naplo;
        }

        // Az események csak "összekötjük" az osztály metódusaival
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            naplo.AktualisTorlese();
        }
    }
}
