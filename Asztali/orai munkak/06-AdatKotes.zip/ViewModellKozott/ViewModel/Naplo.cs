﻿// itt található a beépített Observable Collection
using System.Collections.ObjectModel;

// itt pedig a saját diák modell osztályunk
using ViewModellKozott.Model;

// ennek az osztálynak podig ez a névtere
namespace ViewModellKozott.ViewModel;

public class Naplo
{
    // minden diák tárolása egyetlen gyűjteményben
    public ObservableCollection<Diak> Diakok { get; set; }

    // egyetlen konkrét diák akit épp kiválasztottunk
    public Diak Aktualis { get; set; }

    // konstruktor
    public Naplo()
    {
        // példányosítsuk a gyűjteményt
        Diakok = [
            new Diak("Anita", 10, 'A'),
            new Diak("Bence", 11, 'B'),
            new Diak("Csaba", 12, 'C'),
            new Diak("Dénes", 13, 'D')
        ];
    }

    // példák hasznos jellemzőkre
    public int OsztalyLetszam => Diakok.Count;

    // bármihely hasznos dolgot megfogalamzhatunk
    public bool NincsIttSenki => (Diakok.Count == 0);

    // gyakran nekünk is praktikus és adatköthető is!
    public bool VanValasztottDiak => (Aktualis != null);

    // Metódusok
    public void AktualisTorlese()
    {
        if (VanValasztottDiak)
        {
            Diakok.Remove(Aktualis);
        }
    }
}
