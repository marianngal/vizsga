﻿namespace ViewModellKozott.Model;

public class Diak
{
    public string Nev { get; set; }
    public int Evfolyam { get; set; }
    public char Csoport { get; set; }

    public Diak(string nev, int evfolyam, char csoport)
    {
        Nev = nev;
        Evfolyam = evfolyam;
        Csoport = csoport;
    }

    public override string ToString()
    {
        return $"{Nev} {Evfolyam}. {Csoport}";
    }
}

