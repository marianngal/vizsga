﻿namespace ModellKozott;

public class Student
{
    public string Name { get; set; }
    public int Age { get; set; }

    // "On the fly" property
    // Nincs mögötte mező
    // Minden híváskor újraszámolja
    public bool IsAdult => (Age < 18);

    // Ki lehet próbálni egy tömörebb alakot:
    // A három pöttyen aláhúzott konstruktort kijelölve
    // ctrl + . vagy alt + enter
    // "user primary constructor"
    public Student(string name, int age)
    {
        Name = name;
        Age = age;
    }

    // A ToString() metódus felülírása:
    // hogyan kell a példányt szöveggé alakítani
    public override string ToString()
    {
        return $"{Name} ({Age} év)";
    }
}