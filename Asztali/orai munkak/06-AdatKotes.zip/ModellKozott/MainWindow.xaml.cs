﻿using System.Collections.ObjectModel;
using System.Windows;

namespace ModellKozott;

/// <summary>
/// Interaction logic for MainWindow.xaml
/// </summary>
public partial class MainWindow : Window
{
    // Lista helyett használjuk a "megfigyelhető gyűjteményt",
    // ami értesíti a keretrendszert a lista változásáról.
    public ObservableCollection<Student> students = [];

    public MainWindow()
    {
        InitializeComponent();

        students.Add(new Student("Anita", 10));
        students.Add(new Student("Bence", 20));
        students.Add(new Student("Csaba", 30));
        students.Add(new Student("Dénes", 40));

        // Kössük össze a grafikus felülettel!
        myList.ItemsSource = students;
    }

    private void Button_Click(object sender, RoutedEventArgs e)
    {
        // szükséges adatok
        var name = MyName.Text;
        var age = Convert.ToInt32(MyAge.Text);

        // osztály példányosítása
        var peldany = new Student(name, age);

        // felvétel a diákok közé (nem a listbox.elemi.közé!)
        students.Add(peldany);
    }
}