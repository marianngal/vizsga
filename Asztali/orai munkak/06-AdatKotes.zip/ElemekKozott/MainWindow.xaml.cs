﻿using System.Windows;

namespace ElemekKozott;

/// <summary>
/// Interaction logic for MainWindow.xaml
/// </summary>
public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();

        MyList.Items.Add("Anita");
        MyList.Items.Add("Bence");
        MyList.Items.Add("Csaba");
    }
}