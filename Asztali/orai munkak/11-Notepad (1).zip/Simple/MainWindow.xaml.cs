﻿using System.Windows;

// beépített  ablakokhoz kell (csak Windows)
using Microsoft.Win32;

// fájlkezeléshez kell
using System.IO;

namespace Simple
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void NewClick(object sender, RoutedEventArgs e)
        {
            // korábbi tartalmat töröljük
            szovegdoboz.Text = string.Empty;
        }

        private void SaveClick(object sender, RoutedEventArgs e)
        {
            // új fájl-megnyitó-ablak példányosítása
            SaveFileDialog mentesAblak = new();

            // ablak megnyitása párbeszéd módban és válasz ellenőrzése
            // (előfordulhat, hogy nem kapunk választ, lehet az értéke null)
            if (mentesAblak.ShowDialog() == true)
            {
                // csak akkor végzünk műveletet, ha igaz választ kaptunk
                string utvonal = mentesAblak.FileName;

                // ide szeretnénk menteni
                File.WriteAllText(utvonal, szovegdoboz.Text);
            }
        }

        private void OpenClick(object sender, RoutedEventArgs e)
        {
            // beépített fájl-megnyitó-ablak
            OpenFileDialog megnyitasAblak = new();

            // a választ ellenőrizzük
            if(megnyitasAblak.ShowDialog() == true)
            {
                string utvonal = megnyitasAblak.FileName;

                string tartalom = File.ReadAllText(utvonal);

                szovegdoboz.Text = tartalom;
            }
        }

        private void CloseClick(object sender, RoutedEventArgs e)
        {
            // egyetlen ablak bezárás
            // this.Close();

            // Todo cancel
            MessageBox.Show("Biztos bezárod?");

            // a teljes alkalmazás leállítása
            Application.Current.Shutdown();
        }
    }
}