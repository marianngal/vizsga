﻿using System.Windows;

namespace Model
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        // Az ablak által megjelenített modell
        Counter counter = new Counter();

        public MainWindow()
        {
            InitializeComponent();
        }

        private void MinusClick(object sender, RoutedEventArgs e)
        {
            counter.Decrease();
            SomethingHasChanged();
        }

        private void PlusClick(object sender, RoutedEventArgs e)
        {
            counter.Increase();
            SomethingHasChanged();
        }

        private void SomethingHasChanged()
        {
            myCounterLabel.Content = counter.Current;
            myMinusButton.IsEnabled = counter.CanBeDecreased;
        }
    }
}