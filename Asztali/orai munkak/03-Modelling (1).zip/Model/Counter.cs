﻿namespace Model
{
    public class Counter
    {
        // Kívülról csak olvasható tulajdonság
        public int Current { get; private set; }

        // Alaphelyzetre állító konstruktor
        public Counter()
        {
            Current = 1;
        }

        // Tulajdonságok
        public bool CanBeDecreased => (Current > 0);

        // Működést leíró metódusok
        public void Increase()
        {
            Current++;
        }

        public void Decrease()
        {
            Current--;
        }
    }
}
