﻿using System.Windows;

namespace Fields
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        // Tartsuk számon kódban az alkalmazás állapotát!
        int current = 1;
        bool canBeDecreased = true;

        // Grafikus felület összekötése az állapotokkal
        private void Frissites()
        {
            myCounterLabel.Content = current;
            myMinusButton.IsEnabled = canBeDecreased;
        }

        public MainWindow()
        {
            InitializeComponent();
            Frissites();
        }

        // Események, amik felhasználói interakcióra figyelnek...
        private void MinusClick(object sender, RoutedEventArgs e)
        {
            current--;
            SomethingHasChanged();
        }

        // ... és értesítik az alklmazás logikáját a változásokról
        private void PlusClick(object sender, RoutedEventArgs e)
        {
            current++;
            SomethingHasChanged();
        }

        // Az "üzleti logika"
        private void SomethingHasChanged()
        {
            if (current == 0)
            {
                canBeDecreased = false;
            }
            else
            {
                canBeDecreased = true;
            }

            Frissites();
        }
    }
}