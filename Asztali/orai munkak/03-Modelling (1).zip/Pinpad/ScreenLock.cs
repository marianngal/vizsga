﻿namespace Pinpad
{
    class ScreenLock
    {
        // rejtett mező
        private string password;

        // konstruktor
        public ScreenLock(string password)
        {
            this.password = password;
            Current = string.Empty;
        }

        // nyilvánosan olvasható tulajdonság
        public string Current { get; private set; }

        // on-the-fly property
        public bool Successful => (password == Current);

        // működést leíró metódusok
        public void AddDigit(string digit)
        {
            Current += digit;
        }

        public void RemoveDigit() 
        {
            // Csak legalább 1 karakterből tudunk törölni
            if (Current.Length > 0)
            {
                var oneShorter = Current.Length - 1;
                Current = Current.Substring(0, oneShorter);
            }
        }

        public void ResetCurrent()
        {
            Current = "";

            // vagy

            Current = string.Empty;
        }
    }
}
