﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace Pinpad
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
