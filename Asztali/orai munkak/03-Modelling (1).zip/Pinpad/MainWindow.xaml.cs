﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Pinpad
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        ScreenLock screenLock = new("1234");

        public MainWindow()
        {
            InitializeComponent();
            Refresh();
        }

        public void Refresh()
        {
            myLabel.Content = screenLock.Current;
            myButton.IsEnabled = screenLock.Successful;
        }

        /// <summary>
        /// Egyetlen gomb kattintás esemény sok gombot kezel egyszerre
        /// </summary>
        /// <param name="sender">Aki az eseményt kiváltotta</param>
        /// <param name="e">Az esemény "körülményei"</param>
        private void Append_Click(object sender, RoutedEventArgs e)
        {
            // Az "is" operátor bármilyen változóról
            // eldönti, hogy adott típusú-e

            if (sender is Button)
            {
                // A párja az "as" operátor, ami bármilyen
                // változót megpróbál másik típusúra alakítni
                // (hogyha ez lehetséges)
                Button kuldo = sender as Button;
                object tartalom = kuldo.Content;
                string szoveg = tartalom.ToString();

                screenLock.AddDigit(szoveg);
                Refresh();
            }
        }

        private void Clear_Click(object sender, RoutedEventArgs e)
        {
            screenLock.ResetCurrent();
            Refresh();
        }

        private void Remove_Click(object sender, RoutedEventArgs e)
        {
            screenLock.RemoveDigit();
            Refresh();
        }

        private void Login_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Successful Login!");
        }
    }
}