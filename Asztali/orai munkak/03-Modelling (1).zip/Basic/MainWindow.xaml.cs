﻿using System.Windows;

namespace Basic
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void MinusClick(object sender, RoutedEventArgs e)
        {
            // a legtöbb vezérlő tartalma Object típusú
            // gyakorlatilag bármi tölthető bele tartalomként
            // általában ezek másik vezérlőelemek (például kép)
            var content = myCounterLabel.Content;

            // Átalakítás számmá
            var current = Convert.ToInt32(content);

            // 0-alá ne csökkenjen!
            if (current < 2)
            {
                myMinusButton.IsEnabled = false;
            }
            else
            {
                // Léptetjük eggyel
                myCounterLabel.Content = current - 1;
            }
        }

        private void PlusClick(object sender, RoutedEventArgs e)
        {
            // Rövidebben is írható
            myCounterLabel.Content = Convert.ToInt32(myCounterLabel.Content) + 1;

            // Nulla fölött visszakapcsoljuk a mínusz gombot
            if (myMinusButton.IsEnabled == false)
            {
                myMinusButton.IsEnabled = true;
            }
        }
    }
}