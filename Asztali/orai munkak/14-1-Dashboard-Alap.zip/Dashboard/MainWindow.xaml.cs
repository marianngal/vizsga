﻿using Microsoft.Win32;
using System.Collections.ObjectModel;
using System.IO;
using System.Text.Json;
using System.Windows;

namespace Basic;

/// <summary>
/// Interaction logic for MainWindow.xaml
/// </summary>
public partial class MainWindow : Window
{
    // A felhasználók listája
    ObservableCollection<string> users = ["Anita", "Bence", "Csaba"];

    public MainWindow()
    {
        InitializeComponent();

        // kössük össze a users nevű listát
        // a grafikus felület ListBoxszával!
        userListBox.ItemsSource = users;
    }

    private void CreateKattintas(object sender, RoutedEventArgs e)
    {
        // az egyszerűség kedvéért csak egy tesztfelhasználót készítsünk
        users.Add("Teszt User");
    }
    private void UpdateKattintas(object sender, RoutedEventArgs e)
    {
        // szerkeszti a kijelölt elemet
        // TODO
    }
    private void DeleteKattintas(object sender, RoutedEventArgs e)
    {
        // törli a választott elemet (ha lehetséges)
        // TODO
    }
    private void SaveKattintas(object sender, RoutedEventArgs e)
    {
        // beépített ablak példányosítása
        SaveFileDialog ablak = new();

        // adjon-e hozzá automatikusan kiterjesztést?
        ablak.AddExtension = true;

        // mi legyen az?
        ablak.DefaultExt = ".json";

        // szűrésnél is jelenjen meg?
        ablak.Filter = "JSON|*.json";

        // ablak megnyitása és válasz mentése (ha volt ilyen?)
        bool? valasz = ablak.ShowDialog();
        
        // csak akkor végzünk művelet, ha ennek az értéke igaz
        if (valasz == true)
        {
            // alakítsunk át a tetszőleges adatunkat JSON formátumra
            string json = JsonSerializer.Serialize(users);

            // szerezzük meg a fájlnevet
            string path = ablak.FileName;

            // végezzük el a fájlba írást
            File.WriteAllText(path, json);
        }
    }

    private void LoadKattintas(object sender, RoutedEventArgs e)
    {
        // Fájlból betölti az adatokat
        OpenFileDialog ablak = new();

        bool? valasz = ablak.ShowDialog();

        if (valasz == true)
        {
            string path = ablak.FileName;

            string json = File.ReadAllText(path);

            users = JsonSerializer.Deserialize<ObservableCollection<string>>(json);

            // ez itt TESCO gazdaságos megoldás
            userListBox.ItemsSource = users;
        }
    }

    private void ExitKattintas(object sender, RoutedEventArgs e)
    {
        // Az aktuális ablak bezárása
        this.Close();

        // az egész alkalmazás beázárása
        // Application.Current.Shutdown();
    }

    private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
    {
        // mielőtt az ablak bezáródni
        var uzenet = "Biztos bezárod?";
        var fejlec = "Megerősítés";
        var gombok = MessageBoxButton.OKCancel;
        var ikonok = MessageBoxImage.Question;

        // ablak megnyitása és válasz tárolása
        var valasz = MessageBox.Show(uzenet, fejlec, gombok, ikonok);

        // ha a felhasználó a mégsére kattintott
        if (valasz == MessageBoxResult.Cancel)
        {
            // akkor vonjuk vissza az eseményt
            e.Cancel = true;
        }
    }
}