﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Haladobban;

/// <summary>
/// Interaction logic for MainWindow.xaml
/// </summary>
public partial class MainWindow : Window
{
    // Az adatok "modellje"
    public List<string> nevsor = ["Ferenc", "Anita", "Bence", "Csaba"];

    // Az ablak konstruktora
    public MainWindow()
    {
        InitializeComponent();

        ValtozasTortent();
    }

    // Parancsok
    private void Create_Click(object sender, RoutedEventArgs e)
    {
        nevsor.Add("Zoltán");
        ValtozasTortent();
    }

    private void Delete_Click(object sender, RoutedEventArgs e)
    {
        if (myListBox.SelectedValue is string szoveg)
        {
            nevsor.Remove(szoveg);
            ValtozasTortent();
        }
    }

    private void SortClick(object sender, RoutedEventArgs e)
    {
        nevsor.Sort();
        ValtozasTortent();
    }

    private void ReverseClick(object sender, RoutedEventArgs e)
    {
        nevsor.Reverse();
        ValtozasTortent();
    }

    /***********************************************************/

    // GUI frissítés
    private void ValtozasTortent()
    {
        // töröljük a korábbi állapotot
        myListBox.Items.Clear();

        // utána pedig töltsük fel a listboxot elemekkel!
        foreach (var item in nevsor)
        {
            myListBox.Items.Add(item);
        }
    }
}