﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Egyszeruen;

/// <summary>
/// Interaction logic for MainWindow.xaml
/// </summary>
public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }

    /// <summary>
    /// Új elem hozzáadása a listához.
    /// Variációk az üres szöveg kezelésére.
    /// </summary>
    private void CreateClick(object sender, RoutedEventArgs e)
    {
        // A szövegdoboz szövege
        string szoveg = myTextBox.Text;

        // Megegyezik az üres szöveggel
        if (szoveg == "")
            return;

        // Megegyezik az üres szöveggel
        if (szoveg == string.Empty) 
            return;

        // Nincs hossza (tehát üres)
        if (szoveg.Length == 0) 
            return;

        // Legalább egy karakter
        if (szoveg.Length > 0)
        {
            // Felvesszük a listába
            myListBox.Items.Add(szoveg);

            // Üresre állítjuk a textbox tartalmát
            myTextBox.Text = string.Empty;

            // Visszahelyezzük rá a fókuszt
            myTextBox.Focus();
        }

        // Akár így is (nincs beállítva vagy üres)
        if (string.IsNullOrEmpty(szoveg))
            return;

        // Akár így is (nincs beállítva vagy üres vagy szóköz-tabulátor-sortörés, stb.
        if (string.IsNullOrWhiteSpace(szoveg))
            return;
    }

    /// <summary>
    /// Elem eltávolítása a listából.
    /// </summary>
    private void DeleteClick(object sender, RoutedEventArgs e)
    {
        var elem = myListBox.SelectedItem;

        // törlés csak akkor értelmezett, ha van kiválasztott elem
        if (elem is not null)
        {
            myListBox.Items.Remove(elem);
        }
    }

    /// <summary>
    /// A fenti kód index használatával is megoldható
    /// </summary>
    private void DeleteByIndex(object sender, RoutedEventArgs e)
    {
        var index = myListBox.SelectedIndex;

        if (index != -1)
        {
            myListBox.Items.RemoveAt(index);
        }
    }

    /// <summary>
    /// Amikor a szövegdoboz tartalma megváltozik.
    /// Csak az ismétlés kedvéért itt nem változón keresztül
    /// érjük el az elemet, hanem a "sender" paraméterből.
    /// </summary>
    /// <remarks>
    /// Vigyázzuk! Az alapértelmezett érték is elsüti az eseményt, 
    /// ami furcsa, nehezen értelmezhető kivételeket eredményezhet!
    /// </remarks>
    private void TextboxTextChanged(object sender, TextChangedEventArgs e)
    {
        // ha a küldő szövegdoboz, akkor alakítsuk is át
        if (sender is TextBox doboz)
        {
            if (doboz.Text.Length > 0)
            {
                myButton.IsEnabled = true;
            }
            else
            {
                myButton.IsEnabled = false;
            }

            // A fentebbi kód tömörebben is írható.
            // Amivel azt fejezzük ki, hogy a gomb állapota
            // a szövegdoboz szövegének hosszától függ.
            // Ez később egy fontos gondolat lesz.
            myButton.IsEnabled = (doboz.Text.Length > 0);
        }
    }

    /// <summary>
    /// A listában megváltozott a kijelölés.
    /// Szándékosan az előző gondolatot ismétli. 
    /// </summary>
    /// <remarks>
    /// A kijelölés akkor is megváltozik,
    /// amikor az aktuális elemet töröljük!
    /// </remarks>
    private void ListBoxSelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (myListBox.SelectedItem is not null)
        {
            myDelete.IsEnabled = true;
        }
        else
        {
            myDelete.IsEnabled = false;
        }

        // Itt is igaz, hogy a gomb állapotát a listbox állapotával akarjuk összekötni.
        // Ezt most kézzel csináljuk. Később praktikus lenne ezt lehetne automatizálni.
        myDelete.IsEnabled = (myListBox.SelectedItem is not null);
    }
}