﻿using System.Text;
using System.Windows;
using System.Windows.Controls;

// A lista osztályt itt találjuk
// Az "általános célú" gyűjtemények között
using System.Collections.Generic;

// Most szükségünk van egy speciális esetre.
// Ezt egy másik könyvtárból érhetjük el
using System.Collections.ObjectModel;

namespace Megfigyelheton;

public partial class MainWindow : Window
{
    /*
     * Cseréljük le a List<string> gyűjteményt 
     * Egy ObservableCollection<string> típusra!
     * Ez egy keretrendszer által "megfigyelhető gyűjtemény".
     * Ami eseményekkel automatikusan jelzi, ha megváltozott.
     * A háttérben: Notify (when) Property (is) Changed
    */
    public ObservableCollection<string> nevsor = ["Anita", "Bence", "Csaba"];

    public MainWindow()
    {
        InitializeComponent();

        // Ne feledkezzünk meg az adatkötésről!
        myListBox.ItemsSource = nevsor;
    }

    /// <summary>
    /// Nincs szükség frissítésre. Automatikusan megtörténik!
    /// </summary>
    private void Create_Click(object sender, RoutedEventArgs e)
    {
        nevsor.Add("Dénes");
    }

    /// <summary>
    /// A típusbiztonságról ettől függetlenül gondoskodnunk kell.
    /// </summary>
    private void Delete_Click(object sender, RoutedEventArgs e)
    {
        if (myListBox.SelectedItem is string szoveg)
        {
            nevsor.Remove(szoveg);
        }
    }
}