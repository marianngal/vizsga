﻿using System.Windows;

namespace Konnyebben;

public partial class MainWindow : Window
{
    public List<string> nevsor = ["Zoltán", "Anita", "Péter", "Bence", "Csaba"];

    public MainWindow()
    {
        InitializeComponent();

        // Kössük össze a kódban lévő névsort a grafikus felülettel!
        // Az adatokat ne a ListBox tárolja, hanem a névsorból vegye.
        myListBox.ItemsSource = nevsor;

        // A ListBox.Items jellemzőjéhez már ne adjuk elemeket!
        // Az adatkötés után ez kivételt eredményezne.
        // myListBox.Items.Add("Zoltán");
    }

    private void Create_Click(object sender, RoutedEventArgs e)
    {
        // Fontos, hogy a névsort manipuláljuk!
        nevsor.Add("Dénes");

        // Nincs szükség saját függvényre, van beépített
        myListBox.Items.Refresh();
    }

    private void Sorting_Click(object sender, RoutedEventArgs e)
    {
        // Rendezzük az adatokat (listákon van ilyen parancs)
        nevsor.Sort();

        // Elég csak jelezni a frissítést
        myListBox.Items.Refresh();
    }
}