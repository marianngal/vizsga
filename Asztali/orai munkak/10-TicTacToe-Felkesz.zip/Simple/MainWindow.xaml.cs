﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Simple
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        // TODO: átalakítjuk majd "MVVM" kialakításra
        // Model (adatok, például Player.cs)
        // VierModel (adatkötés, például Game.cs)
        // View (megjelenítés, események továbbítása)

        string playerA = "X";
        string playerB = "O";

        public string ActivePlayer { get; set; }

        public MainWindow()
        {
            InitializeComponent();

            // mondjuk most mindig kezdjen az "X"
            ActivePlayer = playerA;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            // csak akkor végezzünk műveletet, ha az esemény
            // közvetlen küldője valóban egy gomb

            if (sender is Button gomb)
            {
                // jelöljük meg az aktuális játékos szimbólumával
                gomb.Content = ActivePlayer;

                // kaőcsoljuk ki, hogy ne lehessen később átkattintani
                gomb.IsEnabled = false;

                // az egyik játékost piross, a másikat zölddel jelöljük
                if (ActivePlayer == playerA)
                {
                    gomb.Foreground = Brushes.Green;
                }
                else
                {
                    gomb.Foreground = Brushes.Red;
                }
            }

            // győzött valaki?
            if (IsVictory)
            {
                FeedbackLabel.Content = $"Player {ActivePlayer} is victorious!";

                // érjen véget az eseménykezelés
                return;
            }

            // cseréljük fel a két játékost!
            if (ActivePlayer == playerA)
            {
                ActivePlayer = playerB;
            }
            else
            {
                ActivePlayer = playerA;
            }

            // jelenítsük meg a játék állását
            FeedbackLabel.Content = $"Plyer {ActivePlayer}'s turn to move";
        }

        private void StartGameClick(object sender, RoutedEventArgs e)
        {
            // járjuk végig a panel gyermekei között a gomb típusúakat
            foreach (Button gomb in GameBoard.Children.OfType<Button>())
            {
                // töröljük a játékos szimbólumát
                gomb.Content = "";

                // legyen újra kattintható
                gomb.IsEnabled = true;
            }

            // jelenítsük meg a játék állását
            FeedbackLabel.Content = $"Plyer {ActivePlayer}'s turn to move";

            // el tudnánk tárolni egy külön listában is
            List<Button> gombok = GameBoard.Children.OfType<Button>().ToList();
        }

        /// <summary>
        /// A három győzelmi feltételből legalább egy teljesül.
        /// </summary>
        public bool IsVictory => HorizontalVictory || VerticalVictory || DiagonalVictory;

        /// <summary>
        /// Három vizszintesen összefüggő mezőt az aktív játékos birtokol
        /// </summary>
        public bool HorizontalVictory 
            => BelongsToActivePlayer(gomb0, gomb1, gomb2) 
            || BelongsToActivePlayer(gomb3, gomb4, gomb5) 
            || BelongsToActivePlayer(gomb6, gomb7, gomb8);

        /// <summary>
        /// Három függőlegesen összefüggő mezőt az aktív játékos birtokol
        /// </summary>
        public bool VerticalVictory 
            => BelongsToActivePlayer(gomb0, gomb3, gomb6)
            || BelongsToActivePlayer(gomb1, gomb4, gomb7)
            || BelongsToActivePlayer(gomb2, gomb5, gomb8);

        /// <summary>
        /// Bármelyik két átlót az aktív játékos birtokolja
        /// </summary>
        public bool DiagonalVictory
            => BelongsToActivePlayer(gomb0, gomb4, gomb8)
            || BelongsToActivePlayer(gomb2, gomb4, gomb6);

        /// <summary>
        /// Három gomb példányt vár, és eldönti, hogy mindegyik az aktív játékoshoz tartozik-e.
        /// </summary>
        public bool BelongsToActivePlayer(Button gombA, Button gombB, Button gombC)
        {
            if (gombA.Content != ActivePlayer)
            {
                return false;
            }

            if (gombB.Content != ActivePlayer)
            {
                return false;
            }

            if (gombC.Content != ActivePlayer)
            {
                return false;
            }

            return true;
        }
    }
}