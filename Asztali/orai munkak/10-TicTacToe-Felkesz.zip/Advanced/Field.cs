﻿namespace Advanced
{
    /// <summary>
    /// Egyetlen játékmezőt reprezentáló osztály
    /// </summary>
    public class Field
    {
        public override string ToString()
        {
            return $"Sor: {Row} Oszlop: {Col}";
        }

        /// <summary>
        /// A rács hányadik sorában van
        /// </summary>
        public int Row { get; set; }

        /// <summary>
        /// A rács hányadik oszlopában van
        /// </summary>
        public int Col { get; set; }

        /// <summary>
        /// Konstruktor
        /// </summary>
        public Field(int row, int col)
        {
            Row = row;
            Col = col;
        }

        public Player Player { get; set; }

        /// <summary>
        /// Kényelmi funkció, hogy van-e játékosa
        /// </summary>
        public bool HasPlayer
        {
            get
            {
                return Player is not null;
            }
        }

        /// <summary>
        /// Kényelmi funkció, hogy elfoglalták-e cellát
        /// </summary>
        public bool IsEmpty
        {
            get
            {
                return Player is null;
            }
        }

        /// <summary>
        /// Kényelmi funkció, ami a játékos szimbólumát adja vissza,
        /// vagy üres szöveget, ha a cella még üres.
        /// </summary>
        public string Symbol
        {
            get
            {
                if (IsEmpty)
                {
                    return string.Empty;
                }

                return Player.Symbol;
            }
        }
    }
}