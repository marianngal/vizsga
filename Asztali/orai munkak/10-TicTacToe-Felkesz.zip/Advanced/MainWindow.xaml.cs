﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Advanced
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        /// <summary>
        /// Az aktuális játék példánya
        /// </summary>
        public Game Game { get; set; }

        public MainWindow()
        {
            InitializeComponent();

            // Példányosítjuk a játékot
            Game = new();

            // Rendeljük hozzá az ablakhoz!
            DataContext = Game;
        }
    }
}