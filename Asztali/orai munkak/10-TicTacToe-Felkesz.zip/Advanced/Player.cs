﻿namespace Advanced
{
    /// <summary>
    /// Egyetlen játékos adatait egyben kezelő osztály
    /// </summary>
    public class Player
    {
        public string Symbol { get; set; }
        public string Name { get; set; }

        public Player(string symbol, string name)
        {
            Symbol = symbol;
            Name = name;
        }
    }
}