﻿using System.Collections.ObjectModel;

namespace Advanced
{
    /// <summary>
    /// Magát a játékot kezelő ViewModel
    /// </summary>
    public class Game
    {
        public Player PlayerA { get; set; }
        public Player PlayerB { get; set; }

        /// <summary>
        /// Az éppen aktívan következő játékos
        /// </summary>
        public Player Active { get; set; }

        /// <summary>
        /// A játéktábla cellái
        /// </summary>
        public ObservableCollection<Field> Board { get; set; }

        /// <summary>
        /// Pálya méretei
        /// </summary>
        public int Width { get; set; }
        public int Height { get; set; }

        /// <summary>
        /// Konstruktor
        /// </summary>
        public Game()
        {
            // Két példajátékos
            PlayerA = new("X", "Anita");
            PlayerB = new("O", "Bence");

            // Közülük valaki legyen az aktív (legyen mondjuk 'A')
            Active = PlayerA;

            // Méretek most beledrótozzuk
            Width = 3;
            Height = 3;

            // Figyeljünk rá, hogy a gyűjteményt is el kell készíteni
            Board = [];

            // Töltsük fel a táblát cellákkal!
            for (int row = 0; row < Height; row++)
            {
                for (int col = 0; col < Width; col++)
                {
                    // egyetlen cella példányosítása
                    Field field = new(row, col);

                    // adjuk hozzá a táblához!
                    Board.Add(field);
                }
            }
        }

        public bool HorizontalVictory()
        {
            for(int row = 0; row < Height; row++)
            {
                var sorok = Board.Where(x => x.Row == row);
                var mind = sorok.All(x => x.Player == Active);

                if (mind)
                {
                    return true;
                }
            }

            return false;
        }

        public bool VerticalVictory()
        {
            for (int col = 0; col < Width; col++)
            {
                var oszlopok = Board.Where(x => x.Col == col);
                var mindegyik = oszlopok.All(x => x.Player == Active);

                if (mindegyik)
                {
                    return true;
                }
            }

            return false;
        }

        /// <summary>
        /// Van-e olyan cella a pályán, ami még üres?
        /// A "tábla.bármelyik.mezője.üres"
        /// </summary>
        /// <returns></returns>
        public bool IsAnyLegitMovesLeft()
        {
            return Board.Any(field => field.IsEmpty);
        }

        /// <summary>
        /// Minden cellának van játékosa?
        /// A "tábla.minden.mezőjének.vanJátékosa"
        /// </summary>
        public bool IsEveryFieldTaken()
        {
            return Board.All(field => field.HasPlayer);
        }
    }
}