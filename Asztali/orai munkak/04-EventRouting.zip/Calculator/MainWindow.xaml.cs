﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Calculator
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Model model = new Model();

        public MainWindow()
        {
            InitializeComponent();
            RefreshElements();
        }

        private void RefreshElements()
        {
            CurrentLabel.Content = model.Current;
            DisplayLabel.Content = model.Display;
        }

        private void DigitButtonClick(object sender, RoutedEventArgs esemeny)
        {
            // Az "is" kulcsszó ellenőrzi, hogy adott típusú-e
            if (esemeny.Source is Button)
            {
                // Az "as" kulcsszó adott típusra alakítja (ha ez lehetséges)
                Button button = esemeny.Source as Button;

                // Ennek a gombnak ki tudjuk olvasni a tartalmát
                var content = button.Content;

                // Ez kell nekünk számjegy alakban
                var digit = Convert.ToInt32(content);
            
                // Átadjuk a modellnek számításra
                model.AppendDigit(digit);

                // Jelezzük, hogy valami megváltozott
                RefreshElements();
            }
        }

        /// <summary>
        /// A fenti megoldás rövidebben is írható,
        /// lényegében ugyazt csinálja.
        /// </summary>
        private void OperatorButtonClick(object sender, RoutedEventArgs esemeny)
        {
            // Ha az esemény kiváltója egy Button volt, bevezet egy ilyen változót
            if (esemeny.Source is Button gomb)
            {
                // Ennek elérhető a szöveggé alakított tartalma
                string szoveg = gomb.Content.ToString();

                // Amit a modell már tud kezelni
                model.ChooseOperator(szoveg);

                // Jelezzük, hogy valami megváltozott
                RefreshElements();
            }
        }
    }
}