﻿namespace Calculator
{
    public class Model
    {
        /// <summary>
        /// Az előző művelet eredménye
        /// </summary>
        public double Display { get; set; }

        /// <summary>
        /// Az aktuális gépelt érték
        /// </summary>
        public double Current { get; private set; }

        /// <summary>
        /// A választott műveleti jel
        /// </summary>
        public string Operator { get; private set; }

        public Model()
        {
            Display = 0;
            Current = 0;
            Operator = string.Empty;
        }

        /// <summary>
        /// Az aktuális érték végére fűz egy számjegyet
        /// </summary>
        public void AppendDigit(int digit)
        {
            Current = Current * 10 + digit;
        }

        public void ChooseOperator(string muvelet)
        {
            Operator = muvelet;

            if (Display == 0)
            {
                Display = Current;
                Current = 0;
            }
            else
            {
                DoTheCalculation();
            }
        }

        private void DoTheCalculation()
        {
            if (Operator == "+")
            {
                Display += Current;
            }
            else if (Operator == "-")
            {
                Display -= Current;
            }
            else if (Operator == "*")
            {
                Display *= Current;
            }
            else if (Operator == "/" && Current != 0)
            {
                Display /= Current;
            }
            else
            {
                return;
            }

            Operator = string.Empty;
            Current = 0;
        }
    }
}
