﻿using System.Windows;
using System.Windows.Controls;

namespace Tunneling
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs esemeny)
        {
            // Az az elem, aki az eseményláncben meghívta a függvényt
            // string message = $"Kattintás történt a {sender.GetType().Name} elemen";

            // Az az elem, aki elindította az eseményláncot
            var akiAzEgeszetElkezdte = esemeny.Source;

            // Ellenőrizzük, hogy valóban gomb küldte-e
            if (akiAzEgeszetElkezdte is Button)
            {
                // Ha igen, akkor át is lehet alakítani gombbá
                Button gomb = akiAzEgeszetElkezdte as Button;

                // Ennek már elérhető bármilyen jellemzője, például a tartalma
                string tartalom = gomb.Content.ToString();

                // Szemléltetéshez többsoros üzenet
                string uzenet = $"""
                    Továbbító: {sender.GetType().Name}
                    Kiváltója: {esemeny.Source.GetType().Name}
                    Tartalom:  {tartalom}
                    """;

                MessageBox.Show(uzenet);
            }
        }

        private void Fenti_Tomoren(object sender, RoutedEventArgs esemeny)
        {
            if (esemeny.Source is Button)
            {
                var button = esemeny.Source as Button;
                var content = button.Content;
                MessageBox.Show(content.ToString()); 
            }
        }
    }
}