﻿using System.Windows;
using System.Windows.Input;

namespace MasikPelda
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void TextBox_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            string message = $"Egy billentyűt lenyomtak a {sender.GetType().Name} elemen";
            MessageBox.Show(message);
        }
    }
}