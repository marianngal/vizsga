﻿using System.Windows;

namespace BindingExample;

/// <summary>
/// Interaction logic for MainWindow.xaml
/// </summary>
public partial class MainWindow : Window
{
    // Példány készítése a ViewModel osztályból
    AutoViewModel viewModel = new();

    public MainWindow()
    {
        InitializeComponent();

        // Az ablak "adatkörnyezetének" beállítása
        DataContext = viewModel;
    }

    /// <summary>
    /// Ellenpélda, amikor nincs adatkötés
    /// </summary>
    private void Create_Click(object sender, RoutedEventArgs e)
    {
        // adatok elkérése a grafikus felületről
        var gyarto = MyGyartoLabel.Text;
        var evjarat = MyEvjaratLabel.Text;
        var fogyasztas = MyFogyasztLabel.Text;
        var elektromos = MyElektroCheckbox.IsChecked == true;

        // továbbításuk a ViewModel felé
        viewModel.ElemLetrehozasa(gyarto, evjarat, fogyasztas, elektromos);

        // alaphelyzetre állítás
        MyGyartoLabel.Text = "";
        MyEvjaratLabel.Text = "";
        MyFogyasztLabel.Text = "";
        MyElektroCheckbox.IsChecked = false;
    }

    /// <summary>
    /// Követendő kialakítás. Nincs további teendőnk az adatkötés miatt.
    /// </summary>
    private void Delete_Click(object sender, RoutedEventArgs e)
    {
        viewModel.AktualisTorlese();
    }
}