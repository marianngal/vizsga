﻿using System.Collections.ObjectModel;

namespace BindingExample;

/// <summary>
/// Ez az osztály felel az autó példányok kezeléséért,
/// nyilvános jellemzőivel segíti az adatkötés kialakítását.
/// (mezőkre vagy privát láthatóságra nem működik a Binding)
/// </summary>
public class AutoViewModel
{
    /// <summary>
    /// Autók gyűjteménye, ami automatikusan kezeli a változást
    /// </summary>
    public ObservableCollection<AutoModel> AutoLista { get; set; }

    /// <summary>
    /// Praktikus lenne tárolni az éppen kiválasztott elemet is
    /// </summary>
    public AutoModel Aktualis { get; set; }

    /// <summary>
    /// Konstruktor tölti fel induló adatokkal
    /// </summary>
    public AutoViewModel()
    {
        AutoLista = [
            new AutoModel("Tesla", 2000, 0.0, true),    
            new AutoModel("BYD", 2010, 1.1, true),
            new AutoModel("Audi", 2020, 2.2, false),
            new AutoModel("Toyota", 2030, 3.3, false),
            new AutoModel("Suzuki", 2040, 4.4, false),
            new AutoModel("Trabant", 2050, 5.5, true),
        ];
    }

    /// <summary>
    /// Működés leírása beszédes metódusokkal
    /// </summary>
    public void AktualisTorlese()
    {
        if (Aktualis is not null)
        {
            AutoLista.Remove(Aktualis);
        }
    }

    /// <summary>
    /// Kényelmi funkciók, ellenőrzések, átalakítások.
    /// </summary>
    public void ElemLetrehozasa(string gyarto, string evjarat, string fogyasztas, bool elektromos)
    {
        try
        {
            AutoLista.Add(new AutoModel()
            {
                Gyarto = gyarto,
                Evjarat = int.Parse(evjarat),
                Fogyasztas = double.Parse(fogyasztas),
                Elektromos = elektromos
            });
        }
        catch
        {
            // ha a fenti blokkban kivétel keletkezne, most nincs teendő
        }
    }

    /// <remarks>
    /// Minden hasznos jellemzőt itt fogalmaznánk meg,
    /// de azok egyelőre nem frissülnének automatikusan.
    /// Erről a témáról később lesz szó.
    /// </remarks>
}
