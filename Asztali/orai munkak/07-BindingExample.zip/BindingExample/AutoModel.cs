﻿namespace BindingExample;

/// <summary>
/// Az adatokat tároló osztály.
/// Később az adatbázis sémája.
/// </summary>
public class AutoModel
{
    // Nyilvános tulajdonságok

    public string Gyarto { get; set; }
    public int Evjarat { get; set; }
    public double Fogyasztas { get; set; }
    public bool Elektromos { get; set; }

    // Konstruktor

    public AutoModel(string gyarto, int evjarat, double fogyasztas, bool elektromos)
    {
        Gyarto = gyarto;
        Evjarat = evjarat;
        Fogyasztas = fogyasztas;
        Elektromos = elektromos;
    }

    // Ha szeretnénk megengedni, hogy adatok nélkül is létrehozható legyen

    public AutoModel()
    {
    }

    // Megjelenítéshez egyelőre írjuk felül az örökölt ToString() metódust!

    public override string ToString()
    {
        return $"{Gyarto} ({Evjarat})";
    }
}
