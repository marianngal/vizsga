﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace Company.ViewModel;

partial class EmployeeViewModel : ObservableObject
{
}
